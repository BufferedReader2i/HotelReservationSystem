package com.hotelreservation.view;

/**
 * @author humeishan
 * @version 1.0
 */
public class Message {
    static String username="neo";
    static String roomType="";
    static int HotelID=1;
    static double price;
    static int occupancy;
}
